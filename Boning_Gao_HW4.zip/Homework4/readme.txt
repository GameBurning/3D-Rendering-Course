I fixed a transformation bug in HW3. It should rotate correctly.
