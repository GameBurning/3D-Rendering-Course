I fixed a transformation bug in HW3. It should rotate, scale and transform correctly.
